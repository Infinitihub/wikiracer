Uses different algorithms such as dfs, bfs, and djisktras to search through wikipedia and return a path from a starting page and ending page
